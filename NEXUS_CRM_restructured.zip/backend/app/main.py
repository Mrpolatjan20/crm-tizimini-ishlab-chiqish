import json
from datetime import datetime, timezone

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from .config import settings
from .database import Base, engine, get_db
from . import models, schemas
from .security import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    require_roles,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.app_name, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"message": "NEXUS CRM API ishlayapti"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/setup/first-admin")
def create_first_admin(data: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.query(models.User).count() > 0:
        raise HTTPException(403, "Admin allaqachon yaratilgan")

    user = models.User(
        full_name=data.full_name,
        username=data.username,
        password_hash=hash_password(data.password),
        role="ADMIN",
    )
    db.add(user)
    db.commit()
    return {"message": "Birinchi admin yaratildi"}


@app.post("/api/auth/login", response_model=schemas.TokenOut)
def login(data: schemas.LoginIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(
        models.User.username == data.username
    ).first()

    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Login yoki parol noto'g'ri")

    if not user.is_active:
        raise HTTPException(403, "Hisob faol emas")

    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}


@app.post("/api/users")
def create_user(data: schemas.UserCreate,
                db: Session = Depends(get_db),
                admin=Depends(require_roles("ADMIN"))):
    if db.query(models.User).filter(
        models.User.username == data.username
    ).first():
        raise HTTPException(400, "Bu login band")

    user = models.User(
        full_name=data.full_name,
        username=data.username,
        password_hash=hash_password(data.password),
        role=data.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "message": "Foydalanuvchi yaratildi"}


@app.get("/api/users")
def list_users(db: Session = Depends(get_db),
               admin=Depends(require_roles("ADMIN"))):
    users = db.query(models.User).all()
    return [
        {
            "id": u.id,
            "full_name": u.full_name,
            "username": u.username,
            "role": u.role,
            "is_active": u.is_active,
        }
        for u in users
    ]


@app.post("/api/clients", response_model=schemas.ClientOut)
def create_client(data: schemas.ClientCreate,
                  db: Session = Depends(get_db),
                  user=Depends(get_current_user)):
    if data.pinfl and db.query(models.Client).filter(
        models.Client.pinfl == data.pinfl
    ).first():
        raise HTTPException(400, "Bu PINFL avval kiritilgan")

    client = models.Client(
        full_name=data.full_name,
        phone=data.phone,
        pinfl=data.pinfl,
        address=data.address,
        created_by=user.id,
    )
    db.add(client)
    db.commit()
    db.refresh(client)
    return client


@app.get("/api/clients")
def list_clients(db: Session = Depends(get_db),
                 user=Depends(get_current_user)):
    return db.query(models.Client).order_by(
        models.Client.id.desc()
    ).all()


@app.post("/api/applications", response_model=schemas.ApplicationOut)
def create_application(data: schemas.ApplicationCreate,
                       db: Session = Depends(get_db),
                       user=Depends(get_current_user)):
    client = db.query(models.Client).filter(
        models.Client.id == data.client_id
    ).first()

    if not client:
        raise HTTPException(404, "Mijoz topilmadi")

    application = models.Application(
        client_id=data.client_id,
        title=data.title,
        description=data.description,
        created_by=user.id,
    )

    db.add(application)
    db.commit()
    db.refresh(application)

    send_notification(
        db,
        ["ADMIN", "MANAGER"],
        "Yangi ariza",
        f"Yangi ariza yaratildi: {application.title}",
        "APPLICATION",
    )
    return application


@app.get("/api/applications")
def list_applications(db: Session = Depends(get_db),
                       user=Depends(get_current_user)):
    return db.query(models.Application).order_by(
        models.Application.id.desc()
    ).all()


@app.patch("/api/applications/{application_id}/decision")
def decide_application(application_id: int,
                       data: schemas.ApplicationDecision,
                       db: Session = Depends(get_db),
                       user=Depends(require_roles("ADMIN", "MANAGER"))):
    if data.status not in ["APPROVED", "REJECTED", "PENDING"]:
        raise HTTPException(400, "Noto'g'ri status")

    application = db.query(models.Application).filter(
        models.Application.id == application_id
    ).first()

    if not application:
        raise HTTPException(404, "Ariza topilmadi")

    application.status = data.status
    application.decided_by = user.id
    application.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": "Ariza holati yangilandi"}


def send_notification(db, roles, title, message, notification_type="INFO"):
    users = db.query(models.User).filter(
        models.User.role.in_(roles),
        models.User.is_active == True,
    ).all()

    for user in users:
        db.add(models.Notification(
            user_id=user.id,
            title=title,
            message=message,
            notification_type=notification_type,
        ))
    db.commit()


@app.get("/api/notifications")
def get_notifications(db: Session = Depends(get_db),
                      user=Depends(get_current_user)):
    return db.query(models.Notification).filter(
        models.Notification.user_id == user.id
    ).order_by(models.Notification.id.desc()).all()


@app.patch("/api/notifications/{notification_id}/read")
def read_notification(notification_id: int,
                      db: Session = Depends(get_db),
                      user=Depends(get_current_user)):
    notification = db.query(models.Notification).filter(
        models.Notification.id == notification_id,
        models.Notification.user_id == user.id,
    ).first()

    if not notification:
        raise HTTPException(404, "Bildirishnoma topilmadi")

    notification.is_read = True
    db.commit()
    return {"message": "O'qildi"}


@app.post("/api/kpi")
def create_kpi(data: schemas.KPIRecordCreate,
               db: Session = Depends(get_db),
               user=Depends(require_roles("ADMIN", "MANAGER"))):
    target = db.query(models.User).filter(
        models.User.id == data.user_id
    ).first()

    if not target:
        raise HTTPException(404, "Foydalanuvchi topilmadi")

    record = models.KPIRecord(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return {"id": record.id, "message": "KPI saqlandi"}


@app.get("/api/kpi")
def list_kpi(period: str | None = None,
             db: Session = Depends(get_db),
             user=Depends(get_current_user)):
    query = db.query(models.KPIRecord)

    if user.role not in ["ADMIN", "MANAGER"]:
        query = query.filter(models.KPIRecord.user_id == user.id)

    if period:
        query = query.filter(models.KPIRecord.period == period)

    return query.order_by(models.KPIRecord.id.desc()).all()


@app.post("/api/auth/change-password")
def change_password(data: schemas.PasswordChange,
                    db: Session = Depends(get_db),
                    user=Depends(get_current_user)):
    if not verify_password(data.old_password, user.password_hash):
        raise HTTPException(400, "Eski parol noto'g'ri")

    user.password_hash = hash_password(data.new_password)
    db.commit()
    return {"message": "Parol o'zgartirildi"}


@app.post("/api/sync")
def sync_data(data: schemas.SyncRequest,
              db: Session = Depends(get_db),
              user=Depends(get_current_user)):
    results = []

    for item in data.items:
        existing = db.query(models.SyncOperation).filter(
            models.SyncOperation.client_operation_id
            == item.client_operation_id
        ).first()

        if existing:
            results.append({
                "client_operation_id": item.client_operation_id,
                "status": "ALREADY_PROCESSED",
            })
            continue

        if item.operation != "CREATE_CLIENT":
            results.append({
                "client_operation_id": item.client_operation_id,
                "status": "UNSUPPORTED_OPERATION",
            })
            continue

        payload = item.payload

        client = models.Client(
            full_name=payload["full_name"],
            phone=payload["phone"],
            pinfl=payload.get("pinfl"),
            address=payload.get("address"),
            created_by=user.id,
        )
        db.add(client)
        db.flush()

        db.add(models.SyncOperation(
            user_id=user.id,
            device_id=data.device_id,
            client_operation_id=item.client_operation_id,
            operation=item.operation,
            payload=json.dumps(payload, ensure_ascii=False),
            status="PROCESSED",
        ))

        results.append({
            "client_operation_id": item.client_operation_id,
            "status": "PROCESSED",
            "client_id": client.id,
        })

    db.commit()
    return {"results": results}


@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db),
              user=Depends(require_roles("ADMIN", "MANAGER"))):
    return {
        "users": db.query(models.User).count(),
        "clients": db.query(models.Client).count(),
        "applications": db.query(models.Application).count(),
        "pending_applications": db.query(models.Application).filter(
            models.Application.status == "PENDING"
        ).count(),
        "approved_applications": db.query(models.Application).filter(
            models.Application.status == "APPROVED"
        ).count(),
        "rejected_applications": db.query(models.Application).filter(
            models.Application.status == "REJECTED"
        ).count(),
    }


@app.get("/api/reports/operator")
def operator_report(db: Session = Depends(get_db),
                    user=Depends(require_roles("ADMIN", "MANAGER"))):
    users = db.query(models.User).filter(
        models.User.role == "OPERATOR"
    ).all()

    return [
        {
            "user_id": operator.id,
            "full_name": operator.full_name,
            "clients": db.query(models.Client).filter(
                models.Client.created_by == operator.id
            ).count(),
            "applications": db.query(models.Application).filter(
                models.Application.created_by == operator.id
            ).count(),
        }
        for operator in users
    ]